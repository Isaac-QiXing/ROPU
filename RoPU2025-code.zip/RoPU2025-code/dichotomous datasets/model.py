# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 22:21:59 2022
Changed on Thu Sep 28 2023   kaili Zhu

@author: xiao.an
"""
import numpy as np
import matplotlib.pyplot as plt


def ROPU_SIG(data_train, pi, alpha, gamma, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]  #第一列是标签
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    for i in range(len(X)):
        error2 = (np.exp(-X[i:i + 1] * w.T)) / ((1 + np.exp(-X[i:i + 1] * w.T)) ** 2)
        error1 = (np.exp(y[i] * X[i:i + 1] * w.T)) / ((1 + np.exp(y[i] * X[i:i + 1] * w.T)) ** 2)
        for j in range(w.shape[1]):
            if y[i] == 1:
                temp[0, j] = w[0, j] - alpha * ((1 / gamma) * error1 * X[i:i + 1, j] * (-2 * pi) + reg * w[0, j])
            else:
                temp[0, j] = w[0, j] - alpha * ((1 / (1 - gamma)) * error2 * X[i:i + 1, j] + reg * w[0, j])
            w = temp

    return w


def ROPU_ATAN(data_train, pi, alpha, gamma, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))

    for i in range(len(X)):
        error1 = 1 / (1 + ((y[i] * X[i:i + 1] * w.T) ** 2))
        error2 = 1 / (1 + ((-X[i:i + 1] * w.T) ** 2))
        for j in range(w.shape[1]):
            if y[i] == 1:
                temp[0, j] = w[0, j] - alpha * (
                        (1 / gamma) * (-1/3.1416) * (2*pi) * error1 * X[i:i+1, j] + reg * w[0, j])
            else:
                temp[0, j] = w[0, j] - alpha * (
                        (1 / (1 - gamma)) * (1 / 3.1416) * error2 * X[i:i+1, j] + reg * w[0, j])
            w = temp

    return w


def OPU_DH(data_train, pi, alpha, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    for i in range(len(X)):
        if y[i] == 1:
            temp = w - alpha * (-pi * X[i:i + 1] + reg * w)
        else:
            if w * X[i, :].T >= 1:
                temp = w - alpha * (X[i:i + 1] + reg * w)
            elif w * X[i, :].T <= -1:
                temp = w - alpha * reg * w
            else:
                temp = w - alpha * (0.5 * X[i:i + 1] + reg * w)
        w = temp

    return w


def OPU_SL(data_train, pi, alpha, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    for i in range(len(X)):
        if y[i] == 1:
            temp = w - alpha * (-pi * X[i:i + 1] + reg * w)
        else:
            temp = w - alpha * (0.5 * (X[i:i + 1] * w.T + 1) * X[i:i + 1] + reg * w)
        w = temp

    return w


def OPU_LOG(data_train, pi, alpha, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    for i in range(len(X)):
        if y[i] == 1:
            temp = w - alpha * (-pi * X[i:i + 1] + reg * w)
        else:
            temp = w - alpha * ((1 / (1 + np.exp(X[i:i + 1] * w.T))) * np.exp(X[i:i + 1] * w.T) * X[i:i + 1] + reg * w)
        w = temp

    return w


def acc_std(W, data_test, method):
    cols = data_test.shape[1]
    X = data_test.iloc[:, 1:cols]
    y = data_test.iloc[:, 0:1]

    X = np.matrix(X.values)
    y = np.matrix(y.values)

    out = []
    for T in range(10):
        count = 0
        for i in range(len(X)):
            if np.sign(X[i:i + 1] * W[T:T + 1].T) - y[i] == 0:  #sign判断（）内为正负零
                count += 1
        out.append(count / len(X))

    acc = np.average(out, axis=0)  #矩阵级别的平均
    acc = float(acc)
    std = np.std(out)
    print('在{0}模型下'.format(method))
    print('分类精度均值：%2.3f' % acc,'分类精度标准差：%2.3f' % std)


#U类样本分类的正误情况

def acc_unlabeled(W, data_test, method):
    cols = data_test.shape[1]
    X = data_test.iloc[:, 1:cols]
    y = data_test.iloc[:, 0:1]

    X = np.matrix(X.values)
    y = np.matrix(y.values)

    result = []
    for T in range(10):
        count = 0
        num = 0
        for i in range(len(X)):
            if y[i] == -1:
                num += 1
                if np.sign(X[i:i + 1] * W[T:T + 1].T) == 1:  # sign判断（）内为正负零
                    count += 1
        result.append(count / num)

    acc = np.average(result, axis=0)   # 矩阵级别的平均
    acc = float(acc)
    print('在{0}模型下'.format(method), 'U类样本分为正类的比例：%2.3f' % acc)
    


def acc_std_ramp(W, data_test, method):
    cols = data_test.shape[1]
    X = data_test.iloc[:, 1:cols]
    y = data_test.iloc[:, 0:1]

    X = np.matrix(X.values)
    y = np.matrix(y.values)

    out = []
    for T in range(10):
        count = 0
        for i in range(len(X)):
            if np.sign(X[i:i + 1] * W[T:T + 1].T) - y[i] == 0:
                count += 1
        out.append(count / len(X))

    acc = np.average(out, axis=0)
    acc = float(acc)
    std = np.std(out)
    print('在{0}模型下'.format(method))
    print('分类精度均值：%2.3f' % acc)
    print('分类精度标准差：%2.3f' % std)


def regretbound(data_train, pi, alpha, gamma, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))

    for i in range(len(X)):

        nabla = -y[i] * (np.exp(y[i] * X[i:i + 1] * w.T)) * X[i:i + 1] / (1 + np.exp(y[i] * X[i:i + 1] * w.T)) ** 2
        nabla2 = np.linalg.norm(nabla, ord=2, axis=1, keepdims=True)

        if nabla2 == 0:
            nabla3 = 0
        else:
            nabla3 = nabla / nabla2

        if y[i] == 1:
            temp = w - alpha * ((2 * pi) * (1 / gamma) * nabla3 + reg * w)
        else:
            temp = w - alpha * ((1 / (1 - gamma)) * nabla3 + reg * w)
        w = temp

    return w


def regret(data_train, pi, alpha, gamma, file):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    theta = np.zeros((1, X.shape[1]))
    Theta = np.zeros((len(X), X.shape[1]))

    parameters = int(theta.shape[1])
    for i in range(len(X)):
        error2 = ((np.exp(y[i] * X[i:i + 1] * theta.T)) / (1 + np.exp(y[i] * X[i:i + 1] * theta.T)) ** 2)
        for j in range(parameters):
            if y[i] == 1:
                theta[0, j] = theta[0, j] - alpha * (1 / gamma) * error2 * X[i:i + 1, j] * (-2 * pi)
            else:
                theta[0, j] = theta[0, j] - alpha * (1 / (1 - gamma)) * error2 * X[i:i + 1, j]
        Theta[i] = theta

    loss = np.zeros(len(X))
    loss_star = np.zeros(len(X))

    for i in range(len(X)):
        loss[i] = 1 / (1 + np.exp(y[i] * X[i:i + 1] * Theta[i:i + 1, :].T))
        loss_star[i] = 1 / (1 + np.exp(y[i] * X[i:i + 1] * theta.T))

    regret = np.zeros(len(X))
    regret[0] = loss[0] - loss_star[0]
    for i in range(1, len(X)):
        regret[i] = regret[i - 1] + loss[i] - loss_star[i]

    Regret = np.zeros(len(X))
    for i in range(len(X)):
        Regret[i] = regret[i] / (i + 1) ** 0.5

    return Regret


def plot_regert(data_train, pi, alpha, gamma, file):
    R = np.zeros((5, len(data_train)))
    for i in range(5):
        R[i] = regret(data_train, pi, alpha, gamma, file)
    REGRET = np.sum(R, axis=0) * 0.2

    x = np.array(range(0, len(data_train), 1))
    plt.figure(figsize=(11, 8))   # 10，5
    plt.scatter(x, REGRET, color='r', marker='.', s=50)

    plt.xlabel('T')
    plt.ylabel('$regret/\sqrt{T}$')
    if file == 'vote.csv':
        plt.ylim([0, 1])
    elif file == 'Australian.csv':
        plt.ylim([0, 2])
    elif file == 'mushroom.csv':
        plt.ylim([0, 2.5])

    else:
        plt.ylim([-0.5, 3])

    ax = plt.gca();
    ax.spines['bottom'].set_linewidth(2);
    ax.spines['left'].set_linewidth(2);
    ax.spines['right'].set_linewidth(2);
    ax.spines['top'].set_linewidth(2);

    plt.xlabel('T', fontdict={'weight': 'normal', 'size': 25})
    plt.ylabel('$Regret/\sqrt{T}$', fontdict={'weight': 'normal', 'size': 25})

    plt.xticks(fontsize=25)
    plt.yticks(fontsize=25)

    plt.plot(x, REGRET, 'r--', label='A')
    plt.show()


"""
#观察U类样本y*f(x)的值及其损失的导函数值，并画图
def SIG(data_train,pi, alpha, reg, gamma):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 1:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    x = []
    error = []

    for i in range(len(X)):
        error1 = np.exp(y[i] * X[i:i + 1] * w.T) / ((1 + np.exp(y[i] * X[i:i + 1] * w.T)) ** 2)
        for j in range(w.shape[1]):
            if y[i] == 1:
                temp[0, j] = w[0, j] - alpha * ((1 / gamma) * error1 * X[i:i + 1, j] * (-2 * pi) + reg * w[0, j])
            else:
                temp[0, j] = w[0, j] - alpha * ((1 / (1 - gamma)) * error1 * X[i:i + 1, j] + reg * w[0, j])
            w = temp
        x1 = float(y[i] * X[i:i + 1] * w.T)
        x.append(x1)
        error1 = float(error1)
        error.append(error1)
        #print(x, error)
    plt.scatter(x, error)
    plt.show()


def plot_derivative(data_train, pi, alpha, gamma, reg):
    x, f = SIG(data_train, pi, alpha, gamma, reg)
    plt.xlabel('$y*f(x)$', fontdict={'weight': 'normal', 'size': 15})
    plt.ylabel('$Loss(y*f(x))$', fontdict={'weight': 'normal', 'size': 15})

#    plt.xticks(fontsize=15)
#    plt.yticks(fontsize=15)

    plt.plot(x, f, 'r--', label='function')
    plt.show()


def Deri_atan(data_train,pi, alpha, reg, gamma, file):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 1:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))    
    x_atan = []
    error_atan = []
    for i in range(len(X)):
        error1 = (y[i] * X[i:i + 1]) / (1 + (y[i] * X[i:i + 1] * w.T) ** 2)
        for j in range(w.shape[1]):
            if y[i] == 1:
                temp = w - alpha * ((1 / gamma) * (-1/3.1416) * (2*pi) * error1 + reg * w)
            else:
                temp = w - alpha * ((1 / (1 - gamma)) * (-1 / 3.1416) * error1 + reg * w)
            w = temp
        x1 = float(y[i] * (X[i:i + 1] * w.T))
        error0 = 1 / (3.1416 * (1 + (y[i] * X[i:i + 1] * w.T) ** 2))
        x_atan.append(x1)
        error0 = float(error0)
        error_atan.append(error0)
    plt.scatter(x_atan, error_atan, s=5, color='red')
    plt.xlabel('$y*f(x)$', fontdict={'weight': 'normal', 'size': 15})
    plt.ylabel('$L‘(y*f(x))$', fontdict={'weight': 'normal', 'size': 15})
    plt.ylim([-0.1, 0.5])
    title = file[: -4]
    plt.title(title)
    #plt.savefig('{0}.png'.format(title))
    plt.show()
    #plt.close()

def Deri_sig(data_train, pi, alpha, reg, gamma, file):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 1:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    x_sig = []
    error_sig = []
    for i in range(len(X)):
        error1 = (y[i] * (np.exp(y[i] * X[i:i + 1] * w.T)) * X[i:i + 1]) / ((1 + np.exp(y[i] * X[i:i + 1] * w.T)) ** 2)
        for j in range(w.shape[1]):
            if y[i] == 1:
                temp = w - alpha * ((1 / gamma) * error1 * (2 * pi) + reg * w)
            else:
                temp = w - alpha * ((1 / (1 - gamma)) * error1 + reg * w)
            w = temp
        x1 = float(y[i] * (X[i:i + 1] * w.T))
        error0 = (np.exp(y[i] * X[i:i + 1] * w.T)) / ((1 + np.exp(y[i] * X[i:i + 1] * w.T)) ** 2)
        x_sig.append(x1)
        error0 = float(error0)
        error_sig.append(error0)
    plt.scatter(x_sig, error_sig, s=5, color='blue')
    plt.xlabel('$y*f(x)$', fontdict={'weight': 'normal', 'size': 15})
    plt.ylabel('$L‘(y*f(x))$', fontdict={'weight': 'normal', 'size': 15})
    plt.ylim([-0.1, 0.5])
    title = file[: -4]
    plt.title(title)
    #plt.savefig('{0}.png'.format(title))
    plt.show()
    #plt.close()

"""
