# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 23:38:22 2022
Changed on Thu Sep 28 2023 kaili Zhu

@author: xiao.an
"""

from data import *
from model import *
import pandas as pd
import numpy as np

r = 0.5  # 0.2 0.3 0.4 0.5
alpha = 0.1  # 0.1 0.01 0.02 0.5
reg = 0.01  # 0.01 0 0.02 0.05


file_list = ['vote.csv', 'Australian.csv', 'Phishing.csv', 'mushroom.csv']
method_list = ['ROPU_SIG', 'ROPU_ATAN', 'OPU_DH', 'OPU_SL']  # ‘OPU_LOG’


for item in file_list:
    print('对于{}数据集'.format(item))
    data_train, data_test, pi, gamma = get_data(item, r)

    W = np.zeros((10, data_train.shape[1] - 2))

    for method in method_list:
        for i in range(10):
            if method == 'ROPU_SIG':
                w = ROPU_SIG(data_train, pi, alpha, gamma, reg)
            elif method == 'ROPU_ATAN':
                w = ROPU_ATAN(data_train, pi, alpha, gamma, reg)
            elif method == 'OPU_DH':
                w = OPU_DH(data_train, pi, alpha, reg)
            elif method == "OPU_SL":
                w = OPU_SL(data_train, pi, alpha, reg)
            else:
                w = OPU_LOG(data_train, pi, alpha, reg)
            W[i] = w
        acc_std(W, data_test, method)


#  缺失比例为30%的情况下画出regret图

r = 0.3
for item in file_list:
    data_train, data_test, pi, gamma = get_data2(item, r)
    plot_regert(data_train, pi, alpha, gamma, item)



'''
画出损失函数的导数图
for item in file_list:
    data_train, data_test, pi, gamma = get_data2(item, r)
    Deri_sig(data_train, pi, alpha, reg, gamma, item)
    Deri_atan(data_train, pi, alpha, reg, gamma, item)

'''