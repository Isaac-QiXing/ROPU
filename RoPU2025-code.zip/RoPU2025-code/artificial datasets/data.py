# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 21:50:15 2022
changed on Oct 2023  kaili Zhu

@author: xiao.an
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs


def get_data(size0, size1):
    x0, y0 = make_blobs(n_samples=1000, n_features=2, centers=[[150, 150]],
                        cluster_std=[38.59])

    x2, y2 = make_blobs(n_samples=1000, n_features=2, centers=[[250.3, 260.3]],
                        cluster_std=[49.85])

    x3 = x0[np.bitwise_and(x0[:, 0] < size0, x0[:, 1] > size1)]

    x0_rows = x0.view([('', x0.dtype)] * x0.shape[1])
    x3_rows = x3.view([('', x3.dtype)] * x3.shape[1])

    x1 = np.setdiff1d(x0_rows, x3_rows).view(x0.dtype).reshape(-1, x0.shape[1])

    x5, y5 = make_blobs(n_samples=250, n_features=2, centers=[[150, 142.5]],
                        cluster_std=[38.59])

    x6, y6 = make_blobs(n_samples=250, n_features=2, centers=[[250.3, 260.3]],
                        cluster_std=[49.85])
    return x0, x1, x2, x3, x5, x6, y0, y2, y5, y6, size0, size1


def plot_PN(x1, x2, x3):
    x1_new = pd.DataFrame(x1).sample(frac=0.5, replace=False)
    x2_new = pd.DataFrame(x2).sample(frac=0.5, replace=False)
    x3_new = pd.DataFrame(x3).sample(frac=0.5, replace=False)

    x1_new = np.array(x1_new)
    x2_new = np.array(x2_new)
    x3_new = np.array(x3_new)

    plt.scatter(x1_new[:, 0], x1_new[:, 1], c='b', marker='+',label='Positive Samples')
    plt.scatter(x3_new[:, 0], x3_new[:, 1], c='b', marker='+')
    plt.scatter(x2_new[:, 0], x2_new[:, 1], c='r', marker='.',label='Negative Samples')  # 11.22添加图例
    plt.legend(loc='upper left', fontsize=15)
    plt.rcParams['font.size'] = 25
    plt.savefig('PN.png')
    #  plt.show()
    plt.close()
    return x1_new, x2_new, x3_new


def plot_PU(x1_new, x2_new, x3_new):
    plt.scatter(x1_new[:, 0], x1_new[:, 1], c='b', marker='+',label='Positive Samples')
    plt.scatter(x3_new[:, 0], x3_new[:, 1], c='gray', marker='.',label = 'Unlabeled Samples')
    plt.scatter(x2_new[:, 0], x2_new[:, 1], c='gray', marker='.')   # 11.22添加图例
    plt.legend(loc='upper left', fontsize=15)
    plt.rcParams['font.size'] = 25
    plt.savefig('PU.png')
    # plt.show()
    plt.close()


def get_PU_data(x1, x2, x3, x5, x6, y5, y6, size0, size1):
    X1 = pd.DataFrame(x1)
    X3 = pd.DataFrame(x3)  #
    X2 = pd.DataFrame(x2)

    X = pd.concat([X1, X3, X2], axis=0)
    X = X.reset_index(drop=True)

    data_train = X
    names = ['1', '2']
    data_train.columns = names
    data_train = data_train.apply(lambda x: 2 * (x - np.min(x)) / (np.max(x) - np.min(x)) - 1)

    data_train.insert(0, 'pu', -1)
    data_train.iloc[0:1000 - len(X3), 0:1] = 1
    data_train.insert(1, 'label', -1)
    data_train.iloc[0:1000, 1:2] = 1
    data_train.insert(2, 'ones', 1)

    x5_U = x5[np.bitwise_and(x5[:, 0] < size0, x5[:, 1] > size1)]
    x5_rows = x5.view([('', x5.dtype)] * x5.shape[1])
    x5_U_rows = x5_U.view([('', x5_U.dtype)] * x5_U.shape[1])
    x5_P = np.setdiff1d(x5_rows, x5_U_rows).view(x5.dtype).reshape(-1, x5.shape[1])

    num0 = len(x5_P)
    num1 = len(x5_U)

    X5_P = pd.DataFrame(x5_P)
    X5_U = pd.DataFrame(x5_U)

    X6 = pd.DataFrame(x6)
    data_test = pd.concat([X5_P, X5_U, X6], axis=0)
    names = ['1', '2']
    data_test.columns = names
    data_test = data_test.apply(lambda x: 2 * (x - np.min(x)) / (np.max(x) - np.min(x)) - 1)
    data_test.insert(0, 'label', -1)
    data_test.iloc[0:250, 0:1] = 1
    data_test.insert(1, 'ones', 1)

    return data_train, data_test, num0, num1
