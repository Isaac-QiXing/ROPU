# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 21:50:15 2022
changed on Oct 2023  kaili Zhu

@author: xiao.an
"""

from data import *
from model import *
import numpy as np

size0 = 157  # 120(20%) 134(30%) 146(40%)
size1 = 105  # 107(20%) 100(30%) 105(40%)
x0, x1, x2, x3, x5, x6, y0, y2, y5, y6, size0, size1 = get_data(size0, size1)
plot_PN(x1, x2, x3)
x1_new, x2_new, x3_new = plot_PN(x1, x2, x3)
plot_PU(x1_new, x2_new, x3_new)

data_train, data_test, num0, num1 = get_PU_data(x1, x2, x3, x5, x6, y5, y6, size0, size1)

alpha = 0.1  # 0.01,0.02,0.05
reg = 0  # 0.01,0.02,0.05,0.1
pi = 1000 / 2000
cols = data_test.shape[1]
X = data_test.iloc[:, 1:cols]
y = data_test.iloc[:, 0:1]
X = np.matrix(X.values)
y = np.matrix(y.values)

method_list = ['ROPU_SIG', 'ROPU_ATAN', 'OPU_DH', 'OPU_SL', 'OPU_LOG']
for method in method_list:
    w = np.zeros((10, 3))
    count = np.zeros((10, 1))
    for i in range(10):
        if method == 'ROPU_SIG':
            w[i] = ROPU_SIG(data_train, alpha, pi, reg)
        elif method == 'ROPU_ATAN':
            w[i] = ROPU_ATAN(data_train, alpha, pi, reg)
        elif method == 'OPU_DH':
            w[i] = OPU_DH(data_train, alpha, pi, reg)
        elif method == 'OPU_SL':
            w[i] = OPU_SL(data_train, alpha, pi, reg)
        else:
            w[i] = OPU_LOG(data_train, alpha, pi, reg)
    W = acc_std(w, X, y, method)
    plot_results(W, data_test, num0, num1, method)




