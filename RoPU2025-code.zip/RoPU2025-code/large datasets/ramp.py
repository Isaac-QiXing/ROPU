# -*- coding: utf-8 -*-
"""
Created on Sat May 28 21:45:12 2022

@author: DELL
"""

from pynolca.LapRamp import *
import numpy as np
import pandas as pd

import pynolca
import time

from datetime import timedelta


def get_data(file, r):
    d = pd.read_csv(file, header=None)
    d = d.drop_duplicates()

    d = np.array(d)

    d = 2 * (d - d.min(axis=0)) / (d.max(axis=0) - d.min(axis=0)) - 1

    d = np.insert(d, 1, np.array([1] * len(d)), axis=1)
    np.random.shuffle(d)

    d_p = d[d[:, 0] == 1]
    d_n = d[d[:, 0] == -1]

    d_p_train = d_p[0:int(0.8 * len(d_p))]
    d_n_train = d_n[0:int(0.8 * len(d_n))]

    d_p_test = d_p[int(0.8 * len(d_p)):]
    d_n_test = d_n[int(0.8 * len(d_n)):]

    d_p_train[0:int(r * len(d_p_train)), 0] = -1

    '''
    训练集y为二维，测试集y为一维
    '''

    X = np.concatenate((d_p_train[:, 1:], d_n_train[:, 1:]), axis=0)
    y = np.concatenate((d_p_train[:, 0], d_n_train[:, 0]), axis=0)

    X_test = np.concatenate((d_p_test[:, 1:], d_n_test[:, 1:]), axis=0)
    y_test = np.concatenate((d_p_test[:, 0], d_n_test[:, 0]), axis=0).flatten()

    return X, y, X_test, y_test


if __name__ == '__main__':

    time0 = time.time()
    file_list = ['KDD99.csv', 'BNG_letter_5000_1.csv']

    out_list = []
    for item in file_list:

        out_item_list = []
        for r in [0.2, 0.3, 0.4, 0.5]:

            out = []
            X, y, X_test, y_test = get_data(item, r)

            X, y = pynolca.preprocessing.shuffle(X, y)

            n_sample = 2000
            if len(X) > n_sample:
                X = X[0:n_sample]
                y = y[0:n_sample]

            pi = sum(y.flatten() == 1) / len(y.flatten())

            accuracy_pa_ramp = []
            for T in range(10):
                X, y = pynolca.preprocessing.shuffle(X, y)

                arg_kernel = {'name': 'linear', 'par': 1}  # kernel parameter linear
                t = 0  # parameter of heat kernel
                arg_model = {'gamma_A': 0, 'gamma_I': 0, 'arg_kernel': arg_kernel, 't': t}
                arg_alg = {'maxIte': 50}

                model, iteInf = train_ramp(X, y, arg_model, arg_alg, pi)

                classifier = model['f']
                alpha = model['alpha']
                accuracy_pa_ramp.append(sum(classifier(X_test, alpha).flatten() == y_test) * 1.0 / len(y_test))

            mean = round(np.mean(accuracy_pa_ramp), 3)
            std = round(np.std(accuracy_pa_ramp), 3)

            out.append(r)
            out.append(mean)
            out.append(std)

            out_item_list.append(out)
        out_list.append(out_item_list)

    time1 = time.time()
    timedif = timedelta(seconds=int(round(time1 - time0)))
    for i in range(len(file_list)):
        print('{0}数据集结果{1}'.format(file_list[i], out_list[i]))
    print('耗时：', timedif)
