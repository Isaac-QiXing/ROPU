# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 22:21:59 2022
Changed on Thu Sep 28 2023  kaili Zhu

@author: xiao.an
"""
import numpy as np
import matplotlib.pyplot as plt


def ROPU_SIG(data_train, pi, alpha, gamma, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))

    for i in range(len(X)):

        nabla0 = -(np.exp(y[i] * X[i:i + 1] * w.T)) * X[i:i + 1] / ((1 + np.exp(y[i] * X[i:i + 1] * w.T)) ** 2)
        nabla1 = (np.exp(X[i:i + 1] * w.T)) * X[i:i + 1] / ((1 + np.exp(X[i:i + 1] * w.T)) ** 2)
        nabla2 = np.linalg.norm(nabla0, ord=2, axis=1, keepdims=True)
        nabla4 = np.linalg.norm(nabla1, ord=2, axis=1, keepdims=True)

        if nabla2 == 0:
            nabla3 = 0
        else:
            nabla3 = nabla0 / nabla2
        if nabla4 == 0:
            nabla5 = 0
        else:
            nabla5 = nabla1 / nabla4

        if y[i] == 1:
            temp = w - alpha * ((2 * pi) * (1 / gamma) * nabla3 + reg * w)
        else:
            temp = w - alpha * ((1 / (1 - gamma)) * nabla5 + reg * w)
        w = temp

    return w


def ROPU_ATAN(data_train, pi, alpha, gamma, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))

    for i in range(len(X)):

        nabla = -(X[i:i + 1]) / (3.1416 * (1 + (y[i] * X[i:i + 1] * w.T) ** 2))
        nabla1 = (X[i:i + 1]) / (3.1416 * (1 + (X[i:i + 1] * w.T) ** 2))
        nabla2 = np.linalg.norm(nabla, ord=2, axis=1, keepdims=True)
        nabla4 = np.linalg.norm(nabla1, ord=2, axis=1, keepdims=True)
        if nabla2 == 0:
            nabla3 = 0
        else:
            nabla3 = nabla / nabla2

        if nabla4 == 0:
            nabla5 = 0
        else:
            nabla5 = nabla1 / nabla4

        if y[i] == 1:
            temp = w - alpha * ((1 / gamma) * (2 * pi) * nabla3 + reg * w)
        else:
            temp = w - alpha * ((1 / (1 - gamma)) * nabla5 + reg * w)
        w = temp

    return w


def OPU_DH(data_train, pi, alpha, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    for i in range(len(X)):
        if y[i] == 1:
            temp = w - alpha * (-pi * X[i:i + 1] + reg * w)
        else:
            if w * X[i, :].T >= 1:
                temp = w - alpha * (X[i:i + 1] + reg * w)
            elif w * X[i, :].T <= -1:
                temp = w - alpha * reg * w
            else:
                temp = w - alpha * (0.5 * X[i:i + 1] + reg * w)
        w = temp

    return w


def OPU_SL(data_train, pi, alpha, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    for i in range(len(X)):
        if y[i] == 1:
            temp = w - alpha * (-pi * X[i:i + 1] + reg * w)
        else:
            temp = w - alpha * (0.5 * (X[i:i + 1] * w.T + 1) * X[i:i + 1] + reg * w)
        w = temp

    return w


def OPU_LOG(data_train, pi, alpha, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))
    for i in range(len(X)):
        if y[i] == 1:
            temp = w - alpha * (-pi * X[i:i + 1] + reg * w)
        else:
            temp = w - alpha * ((1 / (1 + np.exp(X[i:i + 1] * w.T))) * np.exp(X[i:i + 1] * w.T) * X[i:i + 1] + reg * w)
        w = temp

    return w


def acc_std(W, data_test, method):
    cols = data_test.shape[1]
    X = data_test.iloc[:, 1:cols]
    y = data_test.iloc[:, 0:1]

    X = np.matrix(X.values)
    y = np.matrix(y.values)

    out = []
    for T in range(10):
        count = 0
        for i in range(len(X)):
            if np.sign(X[i:i + 1] * W[T:T + 1].T) - y[i] == 0:
                count += 1
        out.append(count / len(X))

    acc = np.average(out, axis=0)
    acc = float(acc)
    std = np.std(out)
    print('在{0}模型下'.format(method))
    print('分类精度均值：%2.3f' % acc)
    print('分类精度标准差：%2.3f' % std)


def acc_std_ramp(W, data_test, method):
    cols = data_test.shape[1]
    X = data_test.iloc[:, 1:cols]
    y = data_test.iloc[:, 0:1]

    X = np.matrix(X.values)
    y = np.matrix(y.values)

    out = []
    for T in range(10):
        count = 0
        for i in range(len(X)):
            if np.sign(X[i:i + 1] * W[T:T + 1].T) - y[i] == 0:
                count += 1
        out.append(count / len(X))

    acc = np.average(out, axis=0)
    acc = float(acc)
    std = np.std(out)
    print('在{0}模型下'.format(method))
    print('分类精度均值：%2.3f' % acc)
    print('分类精度标准差：%2.3f' % std)


def regretbound(data_train, pi, alpha, gamma, reg):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    w = np.zeros((1, X.shape[1]))
    temp = np.matrix(np.zeros(w.shape))

    for i in range(len(X)):

        nabla = -y[i] * (np.exp(y[i] * X[i:i + 1] * w.T)) * X[i:i + 1] / (1 + np.exp(y[i] * X[i:i + 1] * w.T)) ** 2
        nabla2 = np.linalg.norm(nabla, ord=2, axis=1, keepdims=True)

        if nabla2 == 0:
            nabla3 = 0
        else:
            nabla3 = nabla / nabla2

        if y[i] == 1:
            temp = w - alpha * ((2 * pi) * (1 / gamma) * nabla3 + reg * w)
        else:
            temp = w - alpha * ((1 / (1 - gamma)) * nabla3 + reg * w)
        w = temp

    return w


def regret(data_train, pi, alpha, gamma, file):
    data_train = data_train.sample(frac=1)
    cols = data_train.shape[1]
    X = data_train.iloc[:, 2:cols]
    y = data_train.iloc[:, 0:1]
    X = np.matrix(X.values)
    y = np.matrix(y.values)

    theta = np.zeros((1, X.shape[1]))
    Theta = np.zeros((len(X), X.shape[1]))

    parameters = int(theta.shape[1])
    for i in range(len(X)):
        error2 = ((np.exp(y[i] * X[i:i + 1] * theta.T)) / (1 + np.exp(y[i] * X[i:i + 1] * theta.T)) ** 2)
        for j in range(parameters):  #
            if y[i] == 1:
                theta[0, j] = theta[0, j] - alpha * (1 / gamma) * error2 * X[i:i + 1, j] * (-2 * pi)
            else:
                theta[0, j] = theta[0, j] - alpha * (1 / (1 - gamma)) * error2 * X[i:i + 1, j]
        Theta[i] = theta

    loss = np.zeros(len(X))
    loss_star = np.zeros(len(X))

    for i in range(len(X)):
        loss[i] = 1 / (1 + np.exp(y[i] * X[i:i + 1] * Theta[i:i + 1, :].T))
        loss_star[i] = 1 / (1 + np.exp(y[i] * X[i:i + 1] * theta.T))

    regret = np.zeros(len(X))
    regret[0] = loss[0] - loss_star[0]
    for i in range(1, len(X)):
        regret[i] = regret[i - 1] + loss[i] - loss_star[i]

    Regret = np.zeros(len(X))
    for i in range(len(X)):
        Regret[i] = regret[i] / (i + 1) ** 0.5

    return Regret


def plot_regert(data_train, pi, alpha, gamma, file):
    R = np.zeros((5, len(data_train)))
    for i in range(5):
        R[i] = regret(data_train, pi, alpha, gamma, file)
    REGRET = np.sum(R, axis=0) * 0.2

    x = np.array(range(0, len(data_train), 1))
    plt.figure(figsize=(11, 8))  # （10，5）

    plt.scatter(x, REGRET, color='r', marker='.', s=50)

    plt.xlabel('T')
    plt.ylabel('$regret/\sqrt{T}$')
    if file == 'vote.csv':
        plt.ylim([0, 1])
    elif file == 'Australian.csv':
        plt.ylim([0, 3])
    elif file == 'BNG_letter_5000_1.csv':
        plt.ylim = ([0, 8])
    elif file == 'KDD99.csv':
        plt.ylim = ([0, 1.5])
    else:
        plt.ylim([-0.5, 3])

    ax = plt.gca();
    ax.spines['bottom'].set_linewidth(2);
    ax.spines['left'].set_linewidth(2);
    ax.spines['right'].set_linewidth(2);
    ax.spines['top'].set_linewidth(2);

    plt.xlabel('T', fontdict={'weight': 'normal', 'size': 25})
    plt.ylabel('$Regret/\sqrt{T}$', fontdict={'weight': 'normal', 'size': 25})   # 11.22 修改大小尺寸

    plt.xticks(fontsize=25)   # 11.22 修改大小尺寸
    plt.yticks(fontsize=25)

    plt.plot(x, REGRET, 'r--', label='A')
    plt.show()
