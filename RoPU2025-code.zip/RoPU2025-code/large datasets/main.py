# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 23:38:22 2022

@author: xiao.an
"""

from data import *
from model import *
import pandas as pd
import numpy as np
import time
from datetime import timedelta

time0 = time.time()

r = 0.5  # 0.3 0.4 0.5
alpha = 0.1  # 0.01 0.02 0.5
reg = 0.01  # 0 0.01 0.02 0.05

# file_list=['covtype.xlsx']
# file_list=['BNG_letter_5000_1.csv']
file_list = ['KDD99.csv', 'BNG_letter_5000_1.csv']
method_list = ['ROPU_SIG', 'ROPU_ATAN', 'OPU_DH', 'OPU_SL']
'''
for item in file_list:

    print('对于{0}数据集'.format(item))
    data_train, data_test, pi, gamma = get_data(item, r)
    W = np.zeros((10, data_train.shape[1] - 2))
    for method in method_list:
        for i in range(10):
            if method == 'ROPU_SIG':
                w = ROPU_SIG(data_train, pi, alpha, gamma, reg)
            elif method == 'ROPU_ATAN':
                w = ROPU_ATAN(data_train, pi, alpha, gamma, reg)
            elif method == 'OPU_DH':
                w = OPU_DH(data_train, pi, alpha, reg)
            else:
                w = OPU_SL(data_train, pi, alpha, reg)
            W[i] = w
        acc_std(W, data_test, method)


time1 = time.time()
timedif = timedelta(seconds=int(round(time1 - time0)))
print('耗时：', timedif)

'''

#缺失比例30%情况下的regret可视化

r = 0.3
for item in file_list:
    data_train, data_test, pi, gamma = get_data2(item, r)
    plot_regert(data_train, pi, alpha, gamma, item)
