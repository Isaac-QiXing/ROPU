# -*- coding: utf-8 -*-
"""
Created on Mon Feb 21 21:14:11 2022

@author: xiao.an
"""

import pandas as pd
import numpy as np
from model import *
from data import *

pi = 0.8  # 0.6 1.0 1.2 1.4
alpha = 0.1  # 0.01 0.02 0.05
reg = 0  # 0.01 0.02 0.05 0.1

file_list = ['yeast_.csv', 'tal08_large.csv', 'pbmc_orbit_mips.csv', 'pbmc_velos_mips.csv', 'pbmc_velos_nomips.csv']

for item in file_list:
    d_train, d_rest = get_data(item)
    data_train, num_p_train, gamma = get_train_data(d_train)
    data_test, data_test_P, data_test_U = get_test_data(d_rest)

    method = 'ROPU_SIG'
    m = Model(pi, alpha, reg, gamma)

    Count1 = 0
    Count2 = 0
    p_list = []
    for i in range(10):
        w = m.ROPU_SIG(data_train, num_p_train)
        X2, y2, z2, count1, count2 = outcome(w, data_test_P, data_test_U)
        S = U_P(X2, y2, z2, w)
        p_values = ifrandom(S, data_test_P, data_test_U)
        p_list.append(p_values)

        Count1 += count1
        Count2 += count2
    print('对于{0}数据集'.format(item))
    acc(Count1, Count2, method)
    random_outcome(p_list)

    method = 'OPU_DH'
    m = Model(pi, alpha, reg, gamma)

    Count1 = 0
    Count2 = 0
    p_list = []
    for i in range(10):
        w = m.OPU_DH(data_train)
        X2, y2, z2, count1, count2 = outcome(w, data_test_P, data_test_U)
        S = U_P(X2, y2, z2, w)

        Count1 += count1
        Count2 += count2
    print('对于{0}数据集'.format(item))
    acc(Count1, Count2, method)

    method = 'OPU_SL'
    m = Model(pi, alpha, reg, gamma)

    Count1 = 0
    Count2 = 0
    p_list = []
    for i in range(10):
        w = m.OPU_SL(data_train)
        X2, y2, z2, count1, count2 = outcome(w, data_test_P, data_test_U)
        S = U_P(X2, y2, z2, w)

        Count1 += count1
        Count2 += count2
    print('对于{0}数据集'.format(item))
    acc(Count1, Count2, method)

    method = 'OPU_LOG'
    m = Model(pi, alpha, reg, gamma)

    Count1 = 0
    Count2 = 0
    p_list = []
    for i in range(10):
        w = m.OPU_LOG(data_train)
        X2, y2, z2, count1, count2 = outcome(w, data_test_P, data_test_U)
        S = U_P(X2, y2, z2, w)

        Count1 += count1
        Count2 += count2
    print('对于{0}数据集'.format(item))
    acc(Count1, Count2, method)
