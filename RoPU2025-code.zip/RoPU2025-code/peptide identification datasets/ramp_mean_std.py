# -*- coding: utf-8 -*-
"""
Created on Sat Jun 11 12:03:12 2022

@author: DELL
"""

# -*- coding: utf-8 -*-
"""
Created on Sat May 28 16:34:36 2022

@author: DELL
"""

from pynolca.LapRamp import *
import numpy as np
import pandas as pd

import pynolca
import time

from datetime import timedelta


def get_data(file):
    d = pd.read_csv(file)

    d = np.array(d)

    d = 2 * (d - d.min(axis=0)) / (d.max(axis=0) - d.min(axis=0)) - 1

    d = np.insert(d, 1, np.array([1] * len(d)), axis=1)
    np.random.shuffle(d)

    '''
    训练集特征、标签
    '''
    X = d[0:int(0.8 * len(d)), 1:int(0.8 * len(d))]
    y = d[0:int(0.8 * len(d)), 0:1]

    X_test = d[int(0.8 * len(d)):, :]

    '''
    测试集分为p类和u类
    '''
    X_test1 = X_test[X_test[:, 0] == 1][:, 1:]
    y_test1 = np.array([1] * len(X_test1))

    X_test2 = X_test[X_test[:, 0] == -1][:, 1:]
    y_test2 = np.array([-1] * len(X_test2))

    return X, y, X_test1, y_test1, X_test2, y_test2


if __name__ == '__main__':

    file_list = ['tal08_large.csv', 'yeast_.csv', 'pbmc_velos_mips.csv', 'pbmc_velos_nomips.csv', 'pbmc_orbit_mips.csv']
    # file_list=['tal08_large.csv']
    '''
    分别存放p类和u类召回率
    '''
    ACC_LIST = []
    time0 = time.time()

    all_acc1_list_out = []
    all_acc2_list_out = []

    for item in file_list:

        X, y, X_test1, y_test1, X_test2, y_test2 = get_data(item)

        '''
        数据过多，随机抽取n_sample个
        '''

        size = 500  # 1000 1500 2000
        n_sample_list = [size]

        acc1_list_out = []
        acc2_list_out = []

        for n_sample in n_sample_list:

            X, y = pynolca.preprocessing.shuffle(X, y)

            acc1_list = []
            acc2_list = []

            if len(X) > n_sample:
                X = X[0:n_sample]
                y = y[0:n_sample]

            pi = sum(y.flatten() == 1) / len(y)
            if pi > 0.5:
                pi = 0.5

            for i in range(10):
                X, y = pynolca.preprocessing.shuffle(X, y)

                arg_kernel = {'name': 'linear', 'par': 1}  # kernel parameter
                t = 0  # parameter of heat kernel
                arg_model = {'gamma_A': 0, 'gamma_I': 0, 'arg_kernel': arg_kernel, 't': t}
                arg_alg = {'maxIte': 50}

                model, iteInf = train_ramp(X, y, arg_model, arg_alg, pi)

                classifier = model['f']
                alpha = model['alpha']

                acc1 = round(sum(classifier(X_test1, alpha).flatten() == y_test1) * 1.0 / len(y_test1), 3)
                acc2 = round(sum(classifier(X_test2, alpha).flatten() == y_test2) * 1.0 / len(y_test2), 3)

                acc1_list.append(acc1)
                acc2_list.append(acc2)

            acc1_mean = np.mean(acc1_list)
            acc1_std = np.std(acc1_list)
            acc1_max = max(acc1_list)  # p类召回率最大值

            acc2_mean = np.mean(acc2_list)
            acc2_std = np.std(acc2_list)
            acc2_max = max(acc2_list)  # 与之对应的最大值

            acc1_list_out.append([acc1_mean, acc1_std, acc1_max])
            acc2_list_out.append([acc2_mean, acc2_std, acc2_max])

        all_acc1_list_out.append(acc1_list_out)
        all_acc2_list_out.append(acc2_list_out)

    time1 = time.time()
    timedif = timedelta(seconds=int(round(time1 - time0)))
    print('耗时：', timedif)

print('数据量', n_sample_list)
for i in range(len(file_list)):
    print('对于数据集:', file_list[i], 'P类召回率均值、标准差,最大值', all_acc1_list_out[i])
    print('对于数据集:', file_list[i], 'U类召回率均值、标准差,最大值', all_acc2_list_out[i])
    print('******************************************************************')
