# demo_m_reg.py

from pynolca.LapRamp import *
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import pynolca
import time
import pickle
# load data 
from sklearn.datasets import make_blobs

from data import *
from datetime import timedelta

time0=time.time()
file_list=['vote.csv','Australian.csv','Phishing.csv','mushroom.csv']




out_list=[]
r_list=[0.2,0.3,0.4,0.5]


for item in file_list:
    
    out_item_list=[] 
    for r in r_list:
        
        out=[]
        data_train,data_test = get_data(item,r)[0:2]
        
        n_sample=2000
        if len(data_train)>n_sample:
            data_train=data_train.sample(n=n_sample,replace=False) 
        # if len(data_test)>n_sample:
        #     data_test=data_test.sample(n=n_sample,replace=False) 
            
        cols1=data_train.shape[1]  
        cols2=data_test.shape[1]
    
        X =np.array(data_train.iloc[:,2:cols1])
        y =np.array(data_train.iloc[:,0:1]) 
      
        X_test = np.array(data_test.iloc[:,1:cols2])
        y_test = np.array(data_test.iloc[:,0]) 

        pi=sum(y.flatten()==1)/len(y.flatten())
    
 
    
        
        accuracy_pa_ramp = []
        for T in range(10):
            X, y = pynolca.preprocessing.shuffle(X, y)  
   
            arg_kernel = {'name':'linear','par':1} # kernel parameter linear
            t = 0 # parameter of heat kernel 
            arg_model = {'gamma_A':0, 'gamma_I':0,'arg_kernel':arg_kernel,'t':t}
            arg_alg = {'maxIte':50}
           
            model,iteInf = train_ramp(X,y,arg_model,arg_alg,pi)
            
            classifier = model['f']
            alpha = model['alpha']
            accuracy_pa_ramp.append(sum(classifier(X_test,alpha).flatten() == y_test) * 1.0 / len(y_test))
       
        mean=round(np.mean(accuracy_pa_ramp),3)
        std=round(np.std(accuracy_pa_ramp),3)
        
        out.append(r)
        out.append(mean)
        out.append(std)
        
        out_item_list.append(out)
    out_list.append(out_item_list)

    
time1=time.time()
timedif=timedelta(seconds=int(round(time1-time0)))
for i in range(len(file_list)):
    print('{0}数据集结果{1}'.format(file_list[i],out_list[i]))
print('耗时：',timedif)








