# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 23:38:22 2022

@author: xiao.an
"""

from data import *
from model import *
import pandas as pd
import numpy as np

r=0.2#0.3 0.4 0.5
alpha=0.1 #0.01 0.02 0.5
reg=0.01#0 0.02 0.05




file_list=['vote.csv','Australian.csv','Phishing.csv','mushroom.csv']




for item in file_list:
    
    print('对于{0}数据集'.format(item))
    data_train,data_test,pi,gamma = get_data(item,r)
    
    method='ROPU_SIG'
    W=np.zeros((10,data_train.shape[1]-2))
    for i in range(10):
        w=ROPU_SIG(data_train,pi,alpha,gamma,reg)
        W[i]=w   
    acc_std(W,data_test,method)
    
    method='ROPU_ATAN'
    W=np.zeros((10,data_train.shape[1]-2))
    for i in range(10):
        w=ROPU_ATAN(data_train,pi,alpha,gamma,reg)
        W[i]=w   
    acc_std(W,data_test,method)
    
    method='OPU_DH'
    W=np.zeros((10,data_train.shape[1]-2))
    for i in range(10):
        w=OPU_DH(data_train,pi,alpha,reg)
        W[i]=w   
    acc_std(W,data_test,method)
        
    method='OPU_SL'
    W=np.zeros((10,data_train.shape[1]-2))
    for i in range(10):
        w=OPU_DH(data_train,pi,alpha,reg)
        W[i]=w   
    acc_std(W,data_test,method)
    
    method='OPU_LOG'
    W=np.zeros((10,data_train.shape[1]-2))
    for i in range(10):
        w=OPU_LOG(data_train,pi,alpha,reg)
        W[i]=w   
    acc_std(W,data_test,method)
    


'''
缺失比例为30%的情况下画出regret图

'''
r=0.3
for item in file_list:   
    data_train,data_test,pi,gamma = get_data2(item,r)
    plot_regert(data_train,pi,alpha,gamma,item)



















