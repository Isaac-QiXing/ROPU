# -*- coding: utf-8 -*-
"""
Created on Mon Feb 21 21:41:25 2022

@author: xiao.an
"""
import numpy as np

class Model(object):
    def __init__(self,pi,alpha,reg,gamma):
        self.pi=pi
        self.alpha=alpha
        self.reg=reg
        self.gamma=gamma
      
    def ROPU_SIG(self,data_train,num_p_train):  
        data_train = data_train.sample(frac=1) 
        cols = data_train.shape[1]  
        X =data_train.iloc[:,1:cols] 
        y =data_train.iloc[:,0:1] 
        X = np.matrix(X.values)
        y = np.matrix(y.values)  

        w=np.zeros((1,X.shape[1])) 
        temp = np.matrix(np.zeros(w.shape)) 
        
        for i in range(len(X)):         
            error2=((np.exp(y[i]*X[i:i+1]*w.T))/(1+np.exp(y[i]*X[i:i+1]*w.T))**2)    
            for j in range(w.shape[1]): #   
                if y[i]==1:
                    temp[0,j] = w[0,j] - self.alpha*((1/self.gamma)*error2*X[i:i+1,j]*(-2*self.pi)+self.reg*w[0,j])
                else:
                    temp[0,j] = w[0,j] - self.alpha*((1/(1-self.gamma))*error2*X[i:i+1,j]+self.reg*w[0,j])               
                w = temp

        return w

    
    def OPU_DH(self,data_train):
   
        data_train = data_train.sample(frac=1) 
        cols = data_train.shape[1]  
        X =data_train.iloc[:,1:cols] 
        y =data_train.iloc[:,0:1] 
        X = np.matrix(X.values)
        y = np.matrix(y.values)  
        
        w=np.zeros((1,X.shape[1])) 
        temp = np.matrix(np.zeros(w.shape)) 
        for i in range(len(X)):                 
            for j in range(w.shape[1]):  
                if y[i]==1:       
                    temp[0,j] = w[0,j] - self.alpha*((-self.pi)*X[i:i+1,j]+self.reg*w[0,j])
                else:
                    if w*X[i,:].T>=1:
                        temp[0,j] = w[0,j] - self.alpha*(X[i:i+1,j]+self.reg*w[0,j])
                    elif w*X[i,:].T<=-1:
                        temp[0,j] = w[0,j]- self.alpha*self.reg*w[0,j]
                    else:
                        temp[0,j] = w[0,j] - self.alpha*(0.5*X[i:i+1,j]+self.reg*w[0,j])        
            w=temp      
                
        return w
    
    def OPU_SL(self,data_train):
    
        data_train = data_train.sample(frac=1) 
        cols = data_train.shape[1]  
        X =data_train.iloc[:,1:cols] 
        y =data_train.iloc[:,0:1] 
        X = np.matrix(X.values)
        y = np.matrix(y.values)  
        
        w=np.zeros((1,X.shape[1])) 
        temp = np.matrix(np.zeros(w.shape)) 
        for i in range(len(X)):              
            for j in range(X.shape[1]): 
                if y[i]==1:       
                    temp[0,j] = w[0,j] - self.alpha*(-self.pi*X[i:i+1,j]+self.reg*w[0,j]) 
                else:
                    temp[0,j] = w[0,j] -self.alpha*( 0.5*(X[i:i+1]*w.T+1)*X[i:i+1,j]+self.reg*w[0,j] ) 
            w = temp         
                
        return w
    
    
    def OPU_LOG(self,data_train):
    
        data_train = data_train.sample(frac=1) 
        cols = data_train.shape[1]  
        X =data_train.iloc[:,1:cols] 
        y =data_train.iloc[:,0:1] 
        X = np.matrix(X.values)
        y = np.matrix(y.values)  
        
        w=np.zeros((1,X.shape[1])) 
        temp = np.matrix(np.zeros(w.shape)) 
        for i in range(len(X)):              
            for j in range(X.shape[1]): 
                if y[i]==1:       
                    temp[0,j] = w[0,j] - self.alpha*(-self.pi*X[i:i+1,j]+self.reg*w[0,j]) 
                else:
                    temp[0,j] = w[0,j] -self.alpha*( (1/(np.exp(X[i:i+1]*w.T)+1)) *np.exp(X[i:i+1]*w.T)*X[i:i+1,j]+self.reg*w[0,j] ) 
            w = temp         
                
        return w


def outcome(w,data_test_P,data_test_U):
    count1=0
    count2=0
 
    cols = data_test_P.shape[1]  
    X1 = data_test_P.iloc[:,1:cols] 
    y1 =data_test_P.iloc[:,0:1] 

    X1 = np.matrix(X1.values)
    y1 = np.matrix(y1.values)

    z1=np.zeros(len(X1))
    for i in range(len(X1)):                
        z1[i]=np.sign(X1[i:i+1]*w.T)-y1[i]

    for i in range(len(z1)):
        if z1[i]==0:
            count1=count1+1
        else:
            count1=count1+0

    count1=count1/len(z1)

    X2 = data_test_U.iloc[:,1:cols] 
    y2 =data_test_U.iloc[:,0:1] 

    X2 = np.matrix(X2.values)
    y2 = np.matrix(y2.values)

    z2=np.zeros(len(X2))
    for i in range(len(X2)):                
        z2[i]=np.sign(X2[i:i+1]*w.T)-y2[i]

    for i in range(len(z2)):
        if z2[i]==0:
            count2=count2+1
        else:
            count2=count2+0

    count2=count2/len(z2)  
    return X2,y2,z2,count1,count2    
    



def U_P(X2,y2,z2,w):
    S=[]
    for i in range(len(X2)): 
        if np.sign(X2[i:i+1]*w.T)-y2[i]!=0:
            S.append(i)     
    return S
           
def ifrandom(S,data_test_P,data_test_U):
    data_test_U_P=data_test_U.iloc[S,:] 
    from  scipy.stats import ttest_ind, levene 
    lis=['ions','xcorr','deltacn','sprank','hit_mass','numProt','enzN','enzC','xcorrR'] 
    p_values=[]
    for i in lis:
        a=np.array(data_test_P[i])  
        b=np.array(data_test_U_P[i]) 
        if levene(a,b)[1]>0.05:
            p=ttest_ind(a,b)[1] 
            if p<0.05:
                p_values.append(p)
            else:
                p_values.append(p)
        else:  
            p=ttest_ind(a,b,equal_var=False)[1] 
            if p<0.05:
                p_values.append(p)
            else:
                p_values.append(p)
    return p_values


def acc(Count1,Count2,method):
    Count1=Count1/10
    Count2=Count2/10

    print('在{0}模型下'.format(method))
    print('P类被分为正类的比例：%2.3f'%Count1)
    print('U类被分为正类的比例：%2.3f'%Count2)
    

def random_outcome(p_list):
    p_list=np.average(p_list,axis=0)
    lis = ['ions', 'xcorr', 'deltacn', 'sprank', 'hit_mass', 'numProt', 'enzN', 'enzC', 'xcorrR']  
    israndom_id=[]
    israndom_values=[]
    for i in range(len(lis)):
        israndom_id.append(lis[i] + '的p值为：')
        israndom_values.append(round(p_list[i], 4))
    israndom=dict(zip(israndom_id,israndom_values))
    print(israndom)


