# -*- coding: utf-8 -*-
"""
Created on Mon Feb 21 11:55:29 2022

@author: xiao.an
"""

import pandas as pd
import numpy as np

def get_data(file): 
    d = pd.read_csv(file)
    d=d.apply(lambda x:2*(x-np.min(x))/(np.max(x)-np.min(x))-1) 
    d['label'].replace(1,0,inplace=True)
    d['label'].replace(-1,1,inplace=True)
    d['label'].replace(0,-1,inplace=True)

    d=d.sort_values(by='label',ascending=False) 

    d_p=d[d.label==1]
    d_n=d[d.label==-1]

    d1=d_p.sample(n=None,frac=0.8,replace=False) 
    d2=d_n.sample(n=None,frac=0.8,replace=False)

    d_train=pd.concat([d1,d2],axis=0)  
    d_rest=pd.concat([d,d_train,d_train]).drop_duplicates(keep=False)
    
    return d_train,d_rest

def get_train_data(d_train):
    num_p_train=d_train['label'].value_counts()[1]
    gamma=num_p_train/len(d_train)
    data_train=d_train
    data_train.insert(1,'ones',1) 
    return data_train,num_p_train,gamma

def get_test_data(d_rest):
    num_p_test=d_rest['label'].value_counts()[1] 
    data_test=d_rest
    data_test.insert(1,'ones',1) 
    data_test_P=data_test.iloc[0:num_p_test,:]    
    data_test_U=pd.concat([data_test,data_test_P,data_test_P]).drop_duplicates(keep=False)
    return data_test,data_test_P,data_test_U