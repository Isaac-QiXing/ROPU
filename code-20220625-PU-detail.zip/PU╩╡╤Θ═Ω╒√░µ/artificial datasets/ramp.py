# demo_m_reg.py

from pynolca.LapRamp import *
import numpy as np
import pandas as pd 
import matplotlib.pyplot as plt
import pynolca
import time
import pickle
# load data 
from sklearn.datasets import make_blobs

from datetime import timedelta

from data import *


acc_list=[]
std_list=[]

   
SIZE0=[120,134,146,155]
SIZE1=[107,100,105,102]
r_list=['20%','30%','40%','50%']
   


time0=time.time()
for i in range(len(SIZE0)):
    size0=SIZE0[i]
    size1=SIZE1[i]

    r=r_list[i]
    
    x0,x1,x2,x3,x5,x6,y0,y2,y5,y6,size0,size1=get_data(size0,size1)
    data_train,data_test,num0,num1=get_PU_data(x1,x2,x3,x5,x6,y5,y6,size0,size1)
    cols1 = data_train.shape[1]  
    cols2 = data_test.shape[1] 
    
    X =np.array(data_train.iloc[:,2:cols1] )
    y =np.array(data_train.iloc[:,0:1]) 
    
    '''
    测试集y为一维
    '''
    X_test = np.array(data_test.iloc[:,1:cols2] )
    y_test = np.array(data_test.iloc[:,0] )

    accuracy_pa_ramp = []
    times=10
    
    pi=sum(y.flatten()==1)/len(y.flatten())
    for T in range(times):
        X, y = pynolca.preprocessing.shuffle(X, y)
      
        # arg_kernel = {'name':'rbf','linear','par':1} # kernel parameter
        arg_kernel = {'name':'linear','par':1} # kernel parameter
        t = 0 # parameter of heat kernel 
        arg_model = {'gamma_A':0, 'gamma_I':0,'arg_kernel':arg_kernel,'t':t}
        arg_alg = {'maxIte':50}
       
        model,iteInf = train_ramp(X,y,arg_model,arg_alg,pi)

        classifier = model['f']
        alpha = model['alpha']
       
        accuracy_pa_ramp.append(sum(classifier(X_test,alpha).flatten() == y_test) * 1.0 / len(y_test))

    mean=round(np.mean(accuracy_pa_ramp),times)
    std=round(np.std(accuracy_pa_ramp),times)
  
    acc_list.append(mean)
    std_list.append(std)
    
time1=time.time()
timedif=timedelta(seconds=int(round(time1-time0)))

for i in range(len(r_list)):
    print('缺失比例为{0}时，分类精度均值为{1},标准差为{2}'.format(r_list[i],acc_list[i],std_list[i]))
print('耗时：',timedif)




   





