# -*- coding: utf-8 -*-
"""
Created on Wed Feb 16 20:32:03 2022

@author: xiao.an
"""

import numpy as np
import matplotlib.pyplot as plt

def ROPU_SIG(data_train,alpha,pi,reg):

    data_train = data_train.sample(frac=1) 
    cols = data_train.shape[1]  
    X =data_train.iloc[:,2:cols] 
    y =data_train.iloc[:,0:1] 
    X = np.matrix(X.values)
    y = np.matrix(y.values)  
    gamma=len(data_train.loc[data_train['pu']==1])/len(data_train)
   
    w=np.zeros((1,X.shape[1])) 
    temp = np.matrix(np.zeros(w.shape)) 

    for i in range(len(X)):          
        error2=((np.exp(y[i]*X[i:i+1]*w.T))/(1+np.exp(y[i]*X[i:i+1]*w.T))**2)  
        for j in range(w.shape[1]):  
            if y[i]==1:
                temp[0,j] = w[0,j] - alpha*((1/gamma)*error2*X[i:i+1,j]*(-2*pi)+reg*w[0,j])
            else:
                temp[0,j] = w[0,j] - alpha*((1/(1-gamma))*error2*X[i:i+1,j]+reg*w[0,j])               
            w = temp
            
    return w


def ROPU_ATAN(data_train,alpha,pi,reg):
   
    data_train = data_train.sample(frac=1) 
    cols = data_train.shape[1]  
    X =data_train.iloc[:,2:cols] 
    y =data_train.iloc[:,0:1] 
    X = np.matrix(X.values)
    y = np.matrix(y.values)  
    gamma=len(data_train.loc[data_train['pu']==1])/len(data_train)
    
    w=np.zeros((1,X.shape[1])) 
    temp = np.matrix(np.zeros(w.shape)) 

    for i in range(len(X)):        
        error2=1/(1+(y[i]*X[i:i+1]*w.T)**2)
        for j in range(w.shape[1]): #   
            if y[i]==1:
                temp[0,j] = w[0,j]-alpha*((1/gamma)*(-1/3.1416)*error2*y[i]*X[i:i+1,j]*(2*pi)+reg*w[0,j])
            else:
                temp[0,j] = w[0,j] - alpha*((1/(1-gamma))*(-1/3.1416)*error2*y[i]*X[i:i+1,j]+reg*w[0,j])               
            w = temp
            
    return w



def OPU_DH(data_train,alpha,pi,reg):
   
    data_train = data_train.sample(frac=1) 
    cols = data_train.shape[1] 
    X =data_train.iloc[:,2:cols] 
    y =data_train.iloc[:,0:1] 
    X = np.matrix(X.values)
    y = np.matrix(y.values)  
    
    w=np.zeros((1,X.shape[1])) 
    temp = np.matrix(np.zeros(w.shape)) 
    for i in range(len(X)):                  
        for j in range(w.shape[1]): 
            if y[i]==1:       
                temp[0,j] = w[0,j] - alpha*((-pi)*X[i:i+1,j]+reg*w[0,j])
            else:
                if w*X[i,:].T>=1:
                    temp[0,j] = w[0,j] - alpha*(X[i:i+1,j]+reg*w[0,j])
                elif w*X[i,:].T<=-1:
                    temp[0,j] = w[0,j]- alpha*reg*w[0,j]
                else:
                    temp[0,j] = w[0,j] - alpha*(0.5*X[i:i+1,j]+reg*w[0,j])        
        w=temp      
            
    return w


def OPU_SL(data_train,alpha,pi,reg):
    
    data_train = data_train.sample(frac=1) 
    cols = data_train.shape[1]  
    X =data_train.iloc[:,2:cols] 
    y =data_train.iloc[:,0:1] 
    X = np.matrix(X.values)
    y = np.matrix(y.values)  
    
    w=np.zeros((1,X.shape[1]))
    temp = np.matrix(np.zeros(w.shape)) 
    for i in range(len(X)):                
        for j in range(X.shape[1]): 
            if y[i]==1:       
                temp[0,j] = w[0,j] - alpha*(-pi*X[i:i+1,j]+reg*w[0,j]) 
            else:
                temp[0,j] = w[0,j] -alpha*( 0.5*(X[i:i+1]*w.T+1)*X[i:i+1,j]+reg*w[0,j] ) 
        w = temp         
            
    return w


def OPU_LOG(data_train,alpha,pi,reg):
    
    data_train = data_train.sample(frac=1) 
    cols = data_train.shape[1]  
    X =data_train.iloc[:,2:cols] 
    y =data_train.iloc[:,0:1] 
    X = np.matrix(X.values)
    y = np.matrix(y.values)  
    
    w=np.zeros((1,X.shape[1]))
    temp = np.matrix(np.zeros(w.shape)) 
    for i in range(len(X)):                
        for j in range(X.shape[1]): 
            if y[i]==1:       
                temp[0,j] = w[0,j] - alpha*(-pi*X[i:i+1,j]+reg*w[0,j]) 
            else:
                temp = w-alpha*( (1/(1+np.exp(X[i:i+1]*w.T)))*np.exp(X[i:i+1]*w.T)*X[i:i+1]+reg*w )
        w = temp         
            
    return w




def acc_std(w,X,y,method):
    count=np.zeros((10,1))
    for T in range(10):
        z=np.zeros(len(X))
        for i in range(len(X)):                
            z[i]=np.sign(X[i:i+1]*w[T:T+1].T)-y[i]
            if z[i]==0:
                count[T]=count[T]+1
            else:
                count[T]=count[T]+0    
        count[T]=count[T]/len(z)

    acc=np.average(count,axis=0)
    acc=float(acc) 
    std=np.std(count) 
    w=np.average(w,axis=0)
    print('在{0}模型下'.format(method))
    print('分类精度均值：%2.3f'%acc)
    print('分类精度标准差：%2.3f'%std)
    return w

def acc_std_ramp(w_list,X,y,method,num):
   
    acc_list=[]
    for j in range(num):
        acc=0
        for i in range(len(X)):
            if np.sign(X[i:i+1]*w_list[j:j+1].T)-y[i]==0:
                acc+=1
        acc_list.append(acc/len(X))
        
    acc=np.average(acc_list,axis=0)
    std=np.std(acc_list)
    w=np.average(w_list,axis=0)
    
    print('在{0}模型下'.format(method))
    print('分类精度均值：%2.3f'%acc)
    print('分类精度标准差：%2.3f'%std)
    return w
    
def plot_results(W,data_test,num0,num1,method):
    x=np.linspace(-1,1,5)
    y=(-W[1]/W[2])*x-(W[0]/W[2])
    plt.plot(x,y,linestyle='-',linewidth=2.5,c='black',label='$f(x)=<w,x>$')
    plt.legend(loc='upper left',fontsize=15)
    
    plt.scatter(data_test.iloc[0:num0, 2], data_test.iloc[0:num0, 3], c='b',marker='+',s=50) 
    plt.scatter(data_test.iloc[num0:250, 2], data_test.iloc[num0:250, 3], c='g',marker='+',s=50) 
    plt.scatter(data_test.iloc[250:500, 2], data_test.iloc[250:500, 3], c='r',marker='.',s=50) 
    plt.tick_params(labelsize=18)
    
    # plt.xlabel('X1',fontsize=15) 
    # plt.ylabel('X2',fontsize=15)
    plt.savefig('{0}.png'.format(method))
   # plt.show()
    plt.close()








