* This package, named ROPU_CODE.

* to run the codes please 

* There are three subfolders, corresponding to experiments under dichotomous datasets, artificial datasets and peptide identification datasets respectively

* Each subfolder contains three python files, 'data', 'model', and 'main'

* Corresponding to data acquisition/generation, model establishment and invocation respectively, just run 'main' each time

  Xijun Liang, An Xiao, Kaili Zhang, Suhang Wang and Ling Jian, A Robust Online Positive-Unlabeled Learning Algorithm. 
Submitted to the 38thConference on Uncertainty in Artificial Intelligence(UAI 2022)

 For commercial usage of this package, please contact   Xijun Liang:  liangxijunsd@163.com

2022.2


补充：
每个文件夹下新增一个ramp.py文件，是关于ramp方法的；peptide identification datasets文件夹下还有个ramp_mean_std.py文件，是反映精度和训练样本量关系的。



 
  





