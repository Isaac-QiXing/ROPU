# -*- coding: utf-8 -*-
"""
Created on Fri Feb 18 19:17:52 2022

@author: xiao.an
"""

import pandas as pd
import numpy as np


def get_data(file,r):
    
   

    d=pd.read_csv(file,header=None)
    d=d.drop_duplicates() 
    d=d.apply(lambda x:2*(x-np.min(x))/(np.max(x)-np.min(x))-1)
    d.rename(columns={0:'label'},inplace=True)
    
    d=d.sort_values(by='label',ascending=False) 
    num_p=d['label'].value_counts()[1]
    n=len(d)
    pi=num_p/n

    d_p=d[d.label==1]  
    d_n=d[d.label==-1] 
    
    d1=d_p.sample(n=None,frac=0.8,replace=False) 
    d2=d_n.sample(n=None,frac=0.8,replace=False)
    
    data_train=pd.concat([d1,d2],axis=0) 
    data_test=pd.concat([d,data_train,data_train]).drop_duplicates(keep=False) 
    data_train.insert(1,'ones',1) 
    data_test.insert(1,'ones',1) 
    
    r=1-r
    num=int((len(d1))*r)
    data_train.insert(0,'pu',-1)
    data_train.iloc[0:num,0:1]=1

    gamma=num/len(data_train)
    
    return data_train,data_test,pi,gamma


def get_data_xlsx(file,r):
    
    d = pd.read_excel(file,header=None)
    d=d.drop_duplicates() 
    d=d.apply(lambda x:2*(x-np.min(x))/(np.max(x)-np.min(x))-1)
    d.rename(columns={0:'label'},inplace=True)
    
    d=d.sort_values(by='label',ascending=False) 
    num_p=d['label'].value_counts()[1]
    n=len(d)
    pi=num_p/n

    d_p=d[d.label==1]  
    d_n=d[d.label==-1] 
    
    d1=d_p.sample(n=None,frac=0.8,replace=False) 
    d2=d_n.sample(n=None,frac=0.8,replace=False)
    
    data_train=pd.concat([d1,d2],axis=0) 
    data_test=pd.concat([d,data_train,data_train]).drop_duplicates(keep=False) 
    data_train.insert(1,'ones',1) 
    data_test.insert(1,'ones',1) 
    
    r=1-r
    num=int((len(d1))*r)
    data_train.insert(0,'pu',-1)
    data_train.iloc[0:num,0:1]=1

    gamma=num/len(data_train)
    
    return data_train,data_test,pi,gamma




def get_data2(file,r):
    d = pd.read_csv(file,header = None)
    d=d.drop_duplicates() 
    d=d.apply(lambda x:(x-np.min(x))/(np.max(x)-np.min(x))) 
    d.rename(columns={0:'label'},inplace=True)
    d['label'].replace(0,-1,inplace=True)

    d=d.sort_values(by='label',ascending=False) 
    num_p=d['label'].value_counts()[1]
    n=len(d)
    pi=num_p/n

    d_p=d[d.label==1]  
    d_n=d[d.label==-1] 
    
    d1=d_p.sample(n=None,frac=0.8,replace=False) 
    d2=d_n.sample(n=None,frac=0.8,replace=False)
    
    data_train=pd.concat([d1,d2],axis=0) 
    data_test=pd.concat([d,data_train,data_train]).drop_duplicates(keep=False) 
    data_train.insert(1,'ones',1) 
    data_test.insert(1,'ones',1) 
    
    r=1-r
    num=int((len(d1))*r)
    data_train.insert(0,'pu',-1)
    data_train.iloc[0:num,0:1]=1

    gamma=num/len(data_train)
    
    return data_train,data_test,pi,gamma